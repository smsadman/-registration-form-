

<html>
<head>
<h1> <center> MY PROFILE  </center> <h1>
</head>
<body>

</body>
		
			
				
</fieldset>
    
         
    </table><br><br>
    <table border="5" cellspacing="0" align="center">
       
        <tr>
            <td align="center" height="50" 
                width="100"><br>
                <b> FULL NAME </b></br>
            </td>
            <td align="center" height="50" 
                width="100">
                <b><br> USER NAME </b>
            </td>
            <td align="center" height="50" 
                width="100">
                <b><br> PASSWORD   </b>
				
            </td>
			<td align="center" height="50" 
                width="100">
                <b><br> GMAIL   </b>
            </td>
			<td align="center" height="50" 
                width="100">
                <b><br> PHONE  </b>
            </td>
			
            
        </tr>
        <tr>
            <td align="center" height="50">
                <b>sadman shakib</b></td>
                
            
            <td align="center" height="50">sadman</td>
			 <td align="center" height="50">1234</td>
			  <td align="center" height="50">sadman@gmail.com</td>
			   <td align="center" height="50">01788177948</td>

           
            </tr>
            

 

        
    </table>
       


</table>
<p>Click here to <a href="home-page.php">Home</a></p>
	<p>Click here to <a href="logout.php">Logout</a></p>

</body>
</html>
