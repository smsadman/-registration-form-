<html>
<body>
		
		<footer class="footer">
			<center> <h1> Stay Safe , Stay Home  </h1></center>
		</footer>
		
	</body>
</html>