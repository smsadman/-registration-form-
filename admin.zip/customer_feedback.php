

<html>
<head>
<h1> <center> Customer FeedBack </center> <h1>
</head>
<body>

</body>
		
			
				
</fieldset>
    
         
    </table><br><br>
    <table border="5" cellspacing="0" align="center">
       
        <tr>
            <td align="center" height="50" 
                width="100"><br>
                <b>Serial no </b></br>
            </td>
            <td align="center" height="50" 
                width="100">
                <b><br>User name </b>
            </td>
            <td align="center" height="50" 
                width="100">
                <b><br> Comment   </b>
            </td>
            
        </tr>
        <tr>
            <td align="center" height="50">
                <b>1</b></td>
                
            <td align="center" height="50">sadman shakib</td>
            <td align="center" height="50">nice journey </td>

           
            </tr>
            <tr>
            <td align="center" height="50">
                <b>2</b></td>
            
            <td align="center" height="50">sakil </td>
            <td align="center" height="50">very good journey </td>
            
        </tr>
        <tr>
            <td align="center" height="50">
                <b>3</b></td>
           
            <td align="center" height="50">Rayhan </td>
            <td align="center" height="50">wow!</td>
            
        </tr>

 

        
    </table>
       


</table>
<p>Click here to <a href="home-page.php">Home</a></p>
	<p>Click here to <a href="logout.php">Logout</a></p>

</body>
</html>
