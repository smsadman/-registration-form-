

<html>
<head>
<h1> <center>Employee Information </center><h1>
</head>
<body>

</body>
		
			
				
</fieldset>
    
         
    </table><br><br>
    <table border="5" cellspacing="0" align="center">
       
        <tr>
            <td align="center" height="50" 
                width="100"><br>
                <b>Serial no </b></br>
            </td>
            <td align="center" height="50" 
                width="100">
                <b><br>Full name </b>
            </td>
            <td align="center" height="50" 
                width="100">
                <b><br>User name </b>
            </td>
            <td align="center" height="50" 
                width="100">
                <b><br>Password</b>
            </td>
            <td align="center" height="50" 
                width="100">
                <b><br>Gmail </b>
            </td>
            <td align="center" height="50" 
                width="100">
                <b><br>Phone</b>
            </td>
            
        </tr>
        <tr>
            <td align="center" height="50">
                <b>1</b></td>
                
            <td align="center" height="50">sayed rahman</td>
            <td align="center" height="50">sayed</td>
            <td align="center" height="50">123</td>
            <td align="center" height="50">sayed@gmail.com</td>
            <td align="center" height="50">01788177944</td>

           
            </tr>
            <tr>
            <td align="center" height="50">
                <b>2</b></td>
            
            <td align="center" height="50">suvo </td>
            <td align="center" height="50">khondokar</td>
            <td align="center" height="50">8745</td>
            <td align="center" height="50">suvo@gmail.com</td>
            <td align="center" height="50">01719302039</td>
            
            
        </tr>
        <tr>
            <td align="center" height="50">
                <b>3</b></td>
           
            <td align="center" height="50">Rayhan </td>
            <td align="center" height="50">kabir</td>
            <td align="center" height="50">5676</td>
            <td align="center" height="50">kabir@gmail.com</td>
            <td align="center" height="50">01760288165</td>
           
        </tr>

 

        <tr>
            <td align="center" height="50">
                <b>4</b></td>
            
            <td align="center" height="50">Rahim  </td>
            <td align="center" height="50">rahman</td>
            <td align="center" height="50">097</td>
            <td align="center" height="50">rahim@gmail.com</td>
            <td align="center" height="50">01782637867</td>
           
        </tr>
        
    </table>
       


</table>
<p>Click here to <a href="home-page.php">Home</a></p>
	<p>Click here to <a href="logout.php">Logout</a></p>

</body>
</html>
