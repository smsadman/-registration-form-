

<html>
<head>
<h1> <center> Manager Information </center> <h1>
</head>
<body>

</body>
		
			
				
</fieldset>
    
         
    </table><br><br>
    <table border="5" cellspacing="0" align="center">
       
        <tr>
            <td align="center" height="50" 
                width="100"><br>
                <b>Serial no </b></br>
            </td>
            <td align="center" height="50" 
                width="100">
                <b><br>Full name </b>
            </td>
            <td align="center" height="50" 
                width="100">
                <b><br>User name </b>
            </td>
            <td align="center" height="50" 
                width="100">
                <b><br>Password</b>
            </td>
            <td align="center" height="50" 
                width="100">
                <b><br>Gmail </b>
            </td>
            <td align="center" height="50" 
                width="100">
                <b><br>Phone</b>
            </td>
            
        </tr>
        <tr>
            <td align="center" height="50">
                <b>1</b></td>
                
            <td align="center" height="50">shihab </td>
            <td align="center" height="50">khondokar</td>
            <td align="center" height="50">1234</td>
            <td align="center" height="50">shihab@gmail.com</td>
            <td align="center" height="50">01788177948</td>

           
            </tr>
            <tr>
            <td align="center" height="50">
                <b>2</b></td>
            
            <td align="center" height="50">sakil </td>
            <td align="center" height="50">islam</td>
            <td align="center" height="50">1234</td>
            <td align="center" height="50">sakil@gmail.com</td>
            <td align="center" height="50">01719302035</td>
            
            
        </tr>
        <tr>
            <td align="center" height="50">
                <b>3</b></td>
           
            <td align="center" height="50">Rayhan </td>
            <td align="center" height="50">islam</td>
            <td align="center" height="50">5678</td>
            <td align="center" height="50">rayhan@gmail.com</td>
            <td align="center" height="50">01760288165</td>
           
        </tr>

 

        <tr>
            <td align="center" height="50">
                <b>4</b></td>
            
            <td align="center" height="50">siam </td>
            <td align="center" height="50">islam</td>
            <td align="center" height="50">098</td>
            <td align="center" height="50">siam@gmail.com</td>
            <td align="center" height="50">01782637868</td>
           
        </tr>
        
    </table>
       


</table>
 <p>Click here to <a href="home-page.php">Home</a></p>
	<p>Click here to <a href="logout.php">Logout</a></p>

</body>
</html>
