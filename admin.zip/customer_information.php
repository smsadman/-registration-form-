

<html>
<head>
<h1> <center>Customer Information </center><h1>
</head>
<body>

</body>
		
			
				
</fieldset>
    
         
    </table><br><br>
    <table border="5" cellspacing="0" align="center">
       
        <tr>
            <td align="center" height="50" 
                width="100"><br>
                <b>Serial no </b></br>
            </td>
            <td align="center" height="50" 
                width="100">
                <b><br>Full name </b>
            </td>
            <td align="center" height="50" 
                width="100">
                <b><br>User name </b>
            </td>
            <td align="center" height="50" 
                width="100">
                <b><br>Password</b>
            </td>
            <td align="center" height="50" 
                width="100">
                <b><br>Gmail </b>
            </td>
            <td align="center" height="50" 
                width="100">
                <b><br>Phone</b>
            </td>
            
        </tr>
        <tr>
            <td align="center" height="50">
                <b>1</b></td>
                
            <td align="center" height="50">aktar</td>
            <td align="center" height="50">jaman</td>
            <td align="center" height="50">1234</td>
            <td align="center" height="50">aktar@gmail.com</td>
            <td align="center" height="50">01788177943</td>

           
            </tr>
            <tr>
            <td align="center" height="50">
                <b>2</b></td>
            
            <td align="center" height="50">Alif </td>
            <td align="center" height="50">rahman</td>
            <td align="center" height="50">123909</td>
            <td align="center" height="50">alif@gmail.com</td>
            <td align="center" height="50">01719302032</td>
            
            
        </tr>
        <tr>
            <td align="center" height="50">
                <b>3</b></td>
           
            <td align="center" height="50">kamal </td>
            <td align="center" height="50">khan</td>
            <td align="center" height="50">5678</td>
            <td align="center" height="50">khan@gmail.com</td>
            <td align="center" height="50">01760288168</td>
           
        </tr>

 

        <tr>
            <td align="center" height="50">
                <b>4</b></td>
            
            <td align="center" height="50">sabbir </td>
            <td align="center" height="50">Rahman</td>
            <td align="center" height="50">094</td>
            <td align="center" height="50">sabbir@gmail.com</td>
            <td align="center" height="50">01782637868</td>
           
        </tr>
        
    </table>
       


</table>
  <p>Click here to <a href="home-page.php">Home</a></p>
	<p>Click here to <a href="logout.php">Logout</a></p>

</body>
</html>
